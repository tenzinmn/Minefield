How to run program: Click Run Game (triangle) top right on the Main class
